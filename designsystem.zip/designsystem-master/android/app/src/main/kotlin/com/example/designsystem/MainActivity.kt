package com.example.designsystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
